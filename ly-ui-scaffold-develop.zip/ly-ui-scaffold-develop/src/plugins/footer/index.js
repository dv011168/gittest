import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import { Layout, Icon, Menu} from 'antd';
import { config } from '../../app/config/global';

export default class Footer extends React.Component {
    constructor() {
        super()
    }
    render() {
        return(
            <div className="page_footer">
                Copyright © 2014-2018 LIANYI TECHNOLOGY CO.,LTD. All Rights Reserved. 联奕科技有限公司（{config.version}}）
            </div>
        )
    }

}