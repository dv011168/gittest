export const config = {
    appId : "license",
    title: "授权管理平台",
    english: "",
    version: "V2.0.20170512-31058"
}