
export default {
    namespace: "home",
    state: {
        data: []
    },
    effects: {
        
    },
    reducers: {
       
    }
};
