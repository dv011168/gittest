import Login from "./login";
import Sys from "./sys";

export default [Login, Sys];
